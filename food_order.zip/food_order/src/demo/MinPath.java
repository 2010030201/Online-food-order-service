package demo;
import java.util.HashMap;
/*
import com.twilio.sdk.*;
import com.twilio.sdk.client.TwilioRestClient;
import com.twilio.sdk.resource.api.v2010.Account;
*/
public class MinPath {/*
	public static void main(String[] args) {
		TwilioRestClient client = new TwilioRestClient(System.getenv("TWILIO_ACCOUNT_SID"),System.getenv("TWILIO_AUTH_TOKEN"));
		Account account = client.getAccount();
		SmsFactory factory = account.getSmsFactory();
		HashMap<String,String> msg = new HashMap<>();
		msg.put("To","+919064706514");
		msg.put("From","8001236308");
		msg.put("Body","kinshuk! from mantu!");
		
		factory.create(msg);
	
	}
*/	
}
//this is not requard