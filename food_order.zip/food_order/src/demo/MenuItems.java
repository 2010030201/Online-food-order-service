package demo;

import java.util.ArrayList;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Scalar.String;

public class MenuItems {
	private int price;
	String item_name;
	
	MenuItems(int price,String item_name)
	{
		this.price = price;
		this.item_name = item_name;
		
	}
	
	public void Add_items(int price,String name){
		
		
	}

}
